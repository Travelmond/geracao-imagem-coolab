---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment (please complete the following information):**
 - OS: [e.g. Windows 11]
 - Browser [e.g. chrome, safari]
 - UI and Version: [e.g. SD web UI 1.7.0 ]
 - CivBrowser Version: [e.g. 1.10.0]

**Additional context**
Add any other context about the problem here.
